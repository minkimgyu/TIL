#include<iostream>
#include<string>
#include<stack>
using namespace std;

int main()
{
	ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	stack<int> st;
	string s;

	cin >> s;

	for (int i = 0; i < s.size(); i++)
	{
		int a, b;
		if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
		{
			b = st.top();
			st.pop();
			a = st.top();
			st.pop();

			if (s[i] == '+')
			{
				int tmp = a + b;
				st.push(tmp);
			}
			else if (s[i] == '-')
			{
				int tmp = a - b;
				st.push(tmp);
			}
			else if (s[i] == '*')
			{
				int tmp = a * b;
				st.push(tmp);
			}
			else if (s[i] == '/')
			{
				int tmp = a / b;
				st.push(tmp);
			}
		}
		else
		{
			char c = s[i];
			st.push(atoi(&c));
		}
	}

	cout << st.top();

	return 0;
}