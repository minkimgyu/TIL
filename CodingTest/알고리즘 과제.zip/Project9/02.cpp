#include <iostream>
#include <stack>
#include <string>
using namespace std;

struct Assignment
{
public:
	Assignment(int point, int time)
		:point(point), time(time)
	{

	}

	bool NowFinish()
	{
		return time == 0;
	}

	int DoTesk()
	{
		time--;
		if (time == 0)
		{
			return point;
		}
		else return 0;
	}

private:
	int time;
	int point;
};

int main()
{
	ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

	stack<Assignment*> st;

	int time;
	int score = 0;
	cin >> time;

	for (int i = 0; i < time; i++)
	{
		int receive[3];

		for (int i = 0; i < 3; i++)
		{
			cin >> receive[i];
			if (i == 0 && receive[i] == 0) break;

			if (i == 2)
			{
				st.push(new Assignment(receive[1], receive[2]));
			}
		}

		if (st.size() > 0)
		{
			Assignment* topAssignment = st.top();

			score += topAssignment->DoTesk();
			if (topAssignment->NowFinish() == true)
			{
				st.pop();
			}
		}
	}

	cout << score;

	return 0;
}